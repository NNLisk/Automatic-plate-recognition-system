# Media-Lab > 2022-09-04 11:27am
https://universe.roboflow.com/license-plates-vcmxh/media-lab

Provided by a Roboflow user
License: CC BY 4.0

